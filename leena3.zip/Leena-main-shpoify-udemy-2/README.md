# Leena by WeeklyHow
 Shopify Theme Development Course Project Files by WeeklyHow
 
[Official course page](https://weeklyhow.com/courses/shopify-theme-development-masterclass-learn-how-to-create-shopify-themes/).

This package is built using ThemeKit, so in order for you to be able to customize this package, you either download this repository and upload the theme to a development store, or use ThemeKit for Shopify theme development.